export enum CurateSchema {
  TASKS = "tasks_v1",
  SUMMARY = "summary_v1",
  ENTITIES = "entities_v1",
}

export interface Document {
  id: string;
  content: string;
}

export interface CurateRequest {
  documents: Document[];
  task: string;
  schema: CurateSchema;
}

export interface Task {
  task: string;
  priority: "low" | "medium" | "high";
  deadline: string | null;
  source: string;
}

export interface Entity {
  name: string;
  type: "person" | "organization" | "date" | "location" | "other";
  source: string;
}

export interface CurateMeta {
  chunks_used: number;
  tokens_used: number;
  docs_processed: number;
  tokens_before_filter: number;
  tokens_after_filter: number;
  reduction_pct: number;
}

export interface CurateData {
  tasks?: Task[];
  summary?: string;
  key_points?: string[];
  entities?: Entity[];
}

export interface CurateResponse {
  status: "success" | "error";
  data: CurateData;
  meta: CurateMeta;
  detail?: {
    code: string;
    message: string;
  };
}

import { CurateResponse, CurateSchema, Task, Entity } from "../types";
import TokenReductionBar from "./TokenReductionBar";
import { CheckCircle2, FileText, Tag, ChevronRight } from "lucide-react";

interface ResultViewProps {
  response: CurateResponse;
  schema: CurateSchema;
}

export default function ResultView({ response, schema }: ResultViewProps) {
  const { data, meta } = response;

  const renderTasks = (tasks: Task[]) => (
    <div className="space-y-4">
      {tasks.map((task, i) => (
        <div key={i} className="flex gap-4 p-4 bg-slate-50/50 rounded-xl border border-slate-100 hover:border-slate-200 transition-colors">
          <div className="mt-1">
            <CheckCircle2 size={18} className="text-slate-900" />
          </div>
          <div className="flex-1 space-y-1">
            <div className="flex items-start justify-between gap-4">
              <p className="text-sm font-medium text-slate-900 leading-tight">
                {task.task}
              </p>
              <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                task.priority === 'high' ? 'bg-red-100 text-red-700' :
                task.priority === 'medium' ? 'bg-amber-100 text-amber-700' :
                'bg-blue-100 text-blue-700'
              }`}>
                {task.priority}
              </span>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-slate-500">
              <span className="flex items-center gap-1">
                <FileText size={12} />
                {task.source}
              </span>
              {task.deadline && (
                <span className="bg-slate-100 px-1.5 py-0.5 rounded">
                  deadline: {task.deadline}
                </span>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  const renderSummary = (text?: string, points?: string[]) => (
    <div className="space-y-6">
      {text && (
        <div className="prose prose-slate prose-sm text-slate-600 italic leading-relaxed">
          "{text}"
        </div>
      )}
      {points && points.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Key Points</h4>
          <ul className="space-y-2">
            {points.map((pt, i) => (
              <li key={i} className="flex gap-3 text-sm text-slate-700 items-start">
                <ChevronRight size={16} className="text-slate-400 shrink-0 mt-0.5" />
                {pt}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );

  const renderEntities = (entities: Entity[]) => {
    const grouped = entities.reduce((acc, ent) => {
      if (!acc[ent.type]) acc[ent.type] = [];
      acc[ent.type].push(ent);
      return acc;
    }, {} as Record<string, Entity[]>);

    return (
      <div className="space-y-6">
        {Object.entries(grouped).map(([type, list]) => (
          <div key={type} className="space-y-3">
            <h4 className="text-[10px] uppercase font-bold text-slate-400 tracking-wider font-mono">
              {type}
            </h4>
            <div className="flex flex-wrap gap-2">
              {list.map((ent, i) => (
                <div key={i} className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-sm group hover:border-slate-400 transition-colors">
                  <Tag size={12} className="text-slate-400" />
                  <span className="font-medium text-slate-800">{ent.name}</span>
                  <span className="text-[10px] text-slate-400 font-mono opacity-0 group-hover:opacity-100 transition-opacity">
                    {ent.source}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Stats Board */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 flex flex-col items-center">
          <span className="text-2xl font-bold text-slate-900 leading-none">
            {meta.reduction_pct.toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 uppercase font-semibold mt-2">Reduction</span>
        </div>
        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 flex flex-col items-center text-center">
          <span className="text-2xl font-bold text-slate-900 leading-none">
            {schema === CurateSchema.TASKS ? data.tasks?.length || 0 : 
             schema === CurateSchema.ENTITIES ? data.entities?.length || 0 :
             data.key_points?.length || 1}
          </span>
          <span className="text-[10px] text-slate-400 uppercase font-semibold mt-2">
            {schema === CurateSchema.TASKS ? 'Tasks Found' : 
             schema === CurateSchema.ENTITIES ? 'Entities Found' :
             'Key Insights'}
          </span>
        </div>
        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 flex flex-col items-center">
          <span className="text-2xl font-bold text-slate-900 leading-none">
            {meta.tokens_used}
          </span>
          <span className="text-[10px] text-slate-400 uppercase font-semibold mt-2">Tokens Used</span>
        </div>
      </div>

      <TokenReductionBar percentage={meta.reduction_pct} />

      <div className="pt-4 border-t border-slate-100">
        {schema === CurateSchema.TASKS && data.tasks && renderTasks(data.tasks)}
        {schema === CurateSchema.SUMMARY && renderSummary(data.summary, data.key_points)}
        {schema === CurateSchema.ENTITIES && data.entities && renderEntities(data.entities)}
      </div>
    </div>
  );
}

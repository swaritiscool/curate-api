import { X } from "lucide-react";

interface DocInputProps {
  index: number;
  value: string;
  onChange: (value: string) => void;
  onRemove?: () => void;
  canRemove: boolean;
}

export default function DocInput({ index, value, onChange, onRemove, canRemove }: DocInputProps) {
  return (
    <div className="space-y-2 group relative">
      <div className="flex justify-between items-center">
        <label className="text-xs font-semibold text-slate-500 uppercase tracking-tight">
          Document {index + 1}
        </label>
        {canRemove && (
          <button
            onClick={onRemove}
            className="text-slate-400 hover:text-red-500 transition-colors p-1"
            title="Remove document"
          >
            <X size={14} />
          </button>
        )}
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Paste your text here..."
        className="w-full h-32 p-4 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-900 transition-all resize-none"
      />
    </div>
  );
}

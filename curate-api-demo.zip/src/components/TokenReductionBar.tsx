import { motion } from "motion/react";

interface TokenReductionBarProps {
  percentage: number;
}

export default function TokenReductionBar({ percentage }: TokenReductionBarProps) {
  const displayPercentage = Math.min(100, Math.max(0, percentage));
  
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-end">
        <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
          Token Reduction
        </span>
        <span className="text-sm font-bold text-slate-900">
          {displayPercentage.toFixed(1)}%
        </span>
      </div>
      <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${displayPercentage}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="h-full bg-slate-900 rounded-full"
        />
      </div>
    </div>
  );
}

import { useState } from "react";
import { Plus, ArrowRight, RefreshCw, AlertCircle, Terminal, ExternalLink } from "lucide-react";
import DocInput from "./components/DocInput";
import ResultView from "./components/ResultView";
import { CurateSchema, Document, CurateResponse } from "./types";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [documents, setDocuments] = useState<string[]>([""]);
  const [task, setTask] = useState("extract tasks with deadlines and priorities");
  const [schema, setSchema] = useState<CurateSchema>(CurateSchema.TASKS);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CurateResponse | null>(null);
  const [error, setError] = useState<{ code: string; message: string } | null>(null);
  const [showRaw, setShowRaw] = useState(false);

  const addDocument = () => {
    if (documents.length < 3) {
      setDocuments([...documents, ""]);
    }
  };

  const updateDocument = (index: number, value: string) => {
    const next = [...documents];
    next[index] = value;
    setDocuments(next);
  };

  const removeDocument = (index: number) => {
    if (documents.length > 1) {
      setDocuments(documents.filter((_, i) => i !== index));
    }
  };

  const handleTransform = async () => {
    setLoading(true);
    setError(null);
    setResult(null);

    const docs: Document[] = documents
      .map((content, i) => ({ id: `doc${i + 1}`, content }))
      .filter(d => d.content.trim().length > 0);

    if (docs.length === 0) {
      setError({ code: "VALIDATION_ERROR", message: "Please enter at least one document." });
      setLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/transform", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ documents: docs, task, schema }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.detail || { code: "ERROR", message: "An unexpected error occurred." });
      } else {
        setResult(data);
      }
    } catch (err) {
      setError({
        code: "CONNECTION_FAILED",
        message: "Could not connect to the proxy server."
      });
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setResult(null);
    setError(null);
    setShowRaw(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-slate-200">
      <main className="max-w-2xl mx-auto px-6 py-12 md:py-20">
        
        {/* Header */}
        <header className="mb-12 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-black tracking-tight flex items-center gap-1">
              Curate<span className="text-slate-400">.ai</span>
            </h1>
            <span className="text-[10px] bg-slate-900 text-white px-1.5 py-0.5 rounded font-bold uppercase">Demo</span>
          </div>
          <a 
            href="#" 
            className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1 transition-colors"
          >
            v1.0.4 <ExternalLink size={12} />
          </a>
        </header>

        <AnimatePresence mode="wait">
          {!result && !error ? (
            <motion.section 
              key="input"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              {/* Document Inputs */}
              <div className="space-y-6">
                {documents.map((doc, i) => (
                  <DocInput
                    key={i}
                    index={i}
                    value={doc}
                    onChange={(val) => updateDocument(i, val)}
                    onRemove={() => removeDocument(i)}
                    canRemove={documents.length > 1}
                  />
                ))}

                {documents.length < 3 && (
                  <button
                    onClick={addDocument}
                    className="w-full h-12 border-2 border-dashed border-slate-200 rounded-lg flex items-center justify-center gap-2 text-slate-400 hover:text-slate-600 hover:border-slate-300 transition-all font-medium text-sm"
                  >
                    <Plus size={16} />
                    add another document
                  </button>
                )}
              </div>

              {/* Form Controls */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold text-slate-400">Task</label>
                  <input
                    type="text"
                    value={task}
                    onChange={(e) => setTask(e.target.value)}
                    className="w-full h-11 px-4 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-slate-900 transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold text-slate-400">Schema</label>
                  <select
                    value={schema}
                    onChange={(e) => setSchema(e.target.value as CurateSchema)}
                    className="w-full h-11 px-4 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-slate-900 appearance-none bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2020%2020%22%3E%3Cpath%20stroke%3D%22%236B7280%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%20stroke-width%3D%221.5%22%20d%3D%22m6%208%204%204%204-4%22%2F%3E%3C%2Fsvg%3E')] bg-[length:1.25rem_1.25rem] bg-[right_0.5rem_center] bg-no-repeat"
                  >
                    <option value={CurateSchema.TASKS}>tasks_v1</option>
                    <option value={CurateSchema.SUMMARY}>summary_v1</option>
                    <option value={CurateSchema.ENTITIES}>entities_v1</option>
                  </select>
                </div>
              </div>

              <button
                onClick={handleTransform}
                disabled={loading}
                className="w-full h-14 bg-slate-900 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform active:scale-[0.98]"
              >
                {loading ? (
                  <>
                    <RefreshCw size={18} className="animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    Transform
                    <ArrowRight size={18} />
                  </>
                )}
              </button>
            </motion.section>
          ) : result ? (
            <motion.section 
              key="result"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02 }}
              className="space-y-10"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold tracking-tight">Structured Result</h2>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowRaw(!showRaw)}
                    className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg transition-colors ${
                      showRaw ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-500 hover:bg-slate-50'
                    }`}
                  >
                    <Terminal size={14} />
                    Raw JSON
                  </button>
                </div>
              </div>

              {showRaw ? (
                <div className="bg-slate-900 rounded-2xl p-6 overflow-auto max-h-[60vh] border border-slate-800">
                  <pre className="text-xs text-slate-300 font-mono leading-relaxed">
                    {JSON.stringify(result, null, 2)}
                  </pre>
                </div>
              ) : (
                <ResultView response={result} schema={schema} />
              )}

              <div className="grid grid-cols-2 gap-4 pb-12">
                <button
                  onClick={() => setShowRaw(!showRaw)}
                  className="h-12 border border-slate-200 rounded-xl text-sm font-bold text-slate-500 hover:bg-white transition-colors"
                >
                  {showRaw ? 'View Result' : 'View raw JSON'}
                </button>
                <button
                  onClick={reset}
                  className="h-12 border border-slate-200 rounded-xl text-sm font-bold text-slate-500 hover:bg-white transition-colors"
                >
                  Transform again
                </button>
              </div>
            </motion.section>
          ) : (
            <motion.section 
              key="error"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="py-12"
            >
              <div className="bg-white border-2 border-red-50 p-8 rounded-3xl text-center space-y-6">
                <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto">
                  <AlertCircle size={32} className="text-red-500" />
                </div>
                <div className="space-y-2">
                   <h2 className="text-lg font-bold text-slate-900">
                    {error?.code || 'Error'}
                   </h2>
                   <p className="text-sm text-slate-500 max-w-sm mx-auto leading-relaxed">
                    {error?.message || 'Something went wrong while processing your request.'}
                   </p>
                </div>
                <button
                  onClick={reset}
                  className="px-6 py-2.5 bg-slate-900 text-white rounded-lg text-sm font-bold hover:bg-slate-800 transition-colors"
                >
                  Go back
                </button>
              </div>
            </motion.section>
          )}
        </AnimatePresence>

      </main>

      <footer className="max-w-2xl mx-auto px-6 py-12 text-center border-t border-slate-100">
        <p className="text-[10px] uppercase font-bold text-slate-300 tracking-[0.2em] mb-2">
          Built for context structuring
        </p>
        <div className="flex justify-center gap-1 items-center">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[11px] text-slate-400 font-medium">Local API Status: Online</span>
        </div>
      </footer>
    </div>
  );
}
